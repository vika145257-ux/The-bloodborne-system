package com.selfcontrol.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val pickVideoCode = 11
    private lateinit var videoStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pin = Prefs.pin(this)
        if (pin.isEmpty()) build() else askPin(pin)
    }

    private fun askPin(pin: String) {
        val et = EditText(this)
        et.hint = "PIN"
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        AlertDialog.Builder(this)
            .setTitle("PIN डालो")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("ठीक है") { _, _ ->
                if (et.text.toString() == pin) {
                    build()
                } else {
                    Toast.makeText(this, "गलत PIN", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            .setNegativeButton("वापस") { _, _ -> finish() }
            .show()
    }

    private fun label(text: String, size: Float = 14f, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(0, dp(12), 0, dp(4))
        return t
    }

    private fun build() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(40), dp(16), dp(32))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#101418"))
        scroll.addView(col)

        col.addView(label("सेटिंग", 26f))

        // 1) चालू / बंद
        val sw = Switch(this)
        sw.text = "ब्लॉकिंग चालू"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Prefs.isEnabled(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setEnabled(this, checked) }
        col.addView(sw)

        val sw2 = Switch(this)
        sw2.text = "होम स्क्रीन / लॉक स्क्रीन पर वीडियो न चले"
        sw2.setTextColor(Color.WHITE)
        sw2.isChecked = Prefs.noHomeLaunch(this)
        sw2.setOnCheckedChangeListener { _, checked -> Prefs.setNoHomeLaunch(this, checked) }
        col.addView(sw2)
        col.addView(label("चालू रखने पर वीडियो सिर्फ़ तब चलेगी जब चुना हुआ ऐप सच में सामने खुला हो। होम स्क्रीन पर या फ़ोन अनलॉक करते समय नहीं चलेगी।", 12f, Color.parseColor("#BBBBBB")))

        // 2) वीडियो
        col.addView(label("लॉक वीडियो", 18f))
        videoStatus = label("", 13f, Color.parseColor("#BBBBBB"))
        col.addView(videoStatus)
        updateVideoStatus()

        val pick = Button(this)
        pick.text = "वीडियो चुनो"
        pick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
                .setType("video/*")
                .addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, pickVideoCode)
        }
        col.addView(pick)

        val test = Button(this)
        test.text = "वीडियो टेस्ट करो"
        test.setOnClickListener {
            startActivity(
                Intent(this, LockVideoActivity::class.java)
                    .putExtra(LockVideoActivity.EXTRA_GO_HOME, false)
            )
        }
        col.addView(test)

        // 3) कौन-से ऐप रोकने हैं
        col.addView(label("कौन-से ऐप रोकने हैं", 18f))
        val selected = Prefs.blocked(this).toMutableSet()
        for (app in Apps.launchable(this)) {
            val cb = CheckBox(this)
            cb.text = app.label
            cb.setTextColor(Color.WHITE)
            cb.isChecked = app.pkg in selected
            cb.setOnCheckedChangeListener { _, checked ->
                if (checked) selected.add(app.pkg) else selected.remove(app.pkg)
                Prefs.setBlocked(this, selected)
            }
            col.addView(cb)
        }

        // 4) PIN
        col.addView(label("PIN (सेटिंग खोलने के लिए)", 18f))
        col.addView(label("PIN लगाओगे तो गुस्से/आदत के पल में ख़ुद ब्लॉकिंग बंद नहीं कर पाओगे। खाली छोड़कर दबाओ तो PIN हट जाएगा।", 12f, Color.parseColor("#BBBBBB")))
        val pinBox = EditText(this)
        pinBox.hint = "नया PIN (कम से कम 4 अंक)"
        pinBox.setTextColor(Color.WHITE)
        pinBox.setHintTextColor(Color.GRAY)
        pinBox.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        col.addView(pinBox)
        val pinBtn = Button(this)
        pinBtn.text = "PIN सेव करो"
        pinBtn.setOnClickListener {
            val p = pinBox.text.toString()
            when {
                p.isEmpty() -> {
                    Prefs.setPin(this, "")
                    Toast.makeText(this, "PIN हटा दिया", Toast.LENGTH_SHORT).show()
                }
                p.length < 4 -> Toast.makeText(this, "कम से कम 4 अंक", Toast.LENGTH_SHORT).show()
                else -> {
                    Prefs.setPin(this, p)
                    pinBox.setText("")
                    Toast.makeText(this, "PIN सेव हो गया", Toast.LENGTH_SHORT).show()
                }
            }
        }
        col.addView(pinBtn)

        setContentView(scroll)
    }

    private fun updateVideoStatus() {
        videoStatus.text = if (Prefs.hasVideo(this)) "✅ वीडियो चुनी हुई है" else "वीडियो नहीं चुनी (तब 15 सेकंड का टेक्स्ट दिखेगा)"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickVideoCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("no stream")
                input.use { ins ->
                    Prefs.videoFile(this).outputStream().use { out -> ins.copyTo(out) }
                }
                runOnUiThread {
                    updateVideoStatus()
                    Toast.makeText(this, "वीडियो सेव हो गई", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "वीडियो नहीं मिल पाई, दोबारा चुनो", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
