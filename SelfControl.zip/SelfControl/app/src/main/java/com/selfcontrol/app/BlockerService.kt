package com.selfcontrol.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * सिर्फ़ यह देखता है कि किस ऐप की window सामने है (package name).
 * स्क्रीन का टेक्स्ट/डेटा न पढ़ता है, न सेव करता है, और ऐप में INTERNET permission भी नहीं है।
 *
 * "होम स्क्रीन पर न चले" switch चालू हो तो: चुने हुए ऐप का event आने के बाद 0.4 सेकंड रुककर
 * जाँचता है कि सच में वही ऐप सामने है। होम स्क्रीन, लॉक स्क्रीन या किसी और ऐप के सामने होने पर वीडियो नहीं चलती।
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastLaunch = 0L
    private var pendingPkg: String? = null
    private var retried = false

    private val verify = Runnable {
        val pkg = pendingPkg ?: return@Runnable
        val root = rootInActiveWindow
        val front = root?.packageName?.toString()
        root?.recycle()
        when {
            front == pkg -> launchLock()
            // सामने वाली window पढ़ी नहीं जा सकी: एक बार दोबारा देखो, फिर भी न मिले तो ब्लॉक कर दो
            front == null && !retried -> {
                retried = true
                schedule(pkg, 300)
            }
            front == null -> launchLock()
            // else: होम स्क्रीन / लॉक स्क्रीन / कोई और ऐप सामने है, कुछ नहीं करना
        }
    }

    private fun schedule(pkg: String, delayMs: Long) {
        pendingPkg = pkg
        handler.removeCallbacks(verify)
        handler.postDelayed(verify, delayMs)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!Prefs.isEnabled(this)) return
        if (pkg !in Prefs.blocked(this)) return
        if (LockVideoActivity.active) return

        if (Prefs.noHomeLaunch(this)) {
            retried = false
            schedule(pkg, 400)
        } else {
            launchLock()
        }
    }

    private fun launchLock() {
        if (LockVideoActivity.active) return
        val now = SystemClock.uptimeMillis()
        if (now - lastLaunch < 1500) return
        lastLaunch = now

        val i = Intent(this, LockVideoActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(i)
    }

    override fun onInterrupt() {
        handler.removeCallbacks(verify)
    }

    override fun onDestroy() {
        handler.removeCallbacks(verify)
        super.onDestroy()
    }
}
