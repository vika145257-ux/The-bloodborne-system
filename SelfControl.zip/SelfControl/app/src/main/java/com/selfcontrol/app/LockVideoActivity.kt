package com.selfcontrol.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView

/**
 * वीडियो चलती है, टच और बैक बंद। वीडियो ख़त्म होते ही अपने-आप नॉर्मल।
 * सुरक्षा के लिए 3 बचाव रास्ते:
 *  1) ज़्यादा से ज़्यादा 5 मिनट बाद अपने-आप खुल जाता है
 *  2) वीडियो में एरर आए तो तुरंत खुल जाता है
 *  3) वॉल्यूम-डाउन 5 सेकंड दबाए रखो तो इमरजेंसी एग्ज़िट
 */
class LockVideoActivity : Activity() {

    companion object {
        const val EXTRA_GO_HOME = "go_home"

        @Volatile
        var active = false

        private const val HARD_CAP_MS = 5 * 60 * 1000L
        private const val NO_VIDEO_MS = 15_000L
        private const val ESCAPE_MS = 5_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var finished = false
    private var goHome = true
    private var volStart = 0L
    private var endAt = 0L
    private var video: VideoView? = null
    private lateinit var counter: TextView

    private val tick = object : Runnable {
        override fun run() {
            if (finished) return
            val v = video
            val leftMs: Long = if (v != null) {
                (v.duration - v.currentPosition).toLong()
            } else {
                endAt - SystemClock.uptimeMillis()
            }
            val sec = leftMs.coerceAtLeast(0L) / 1000 + 1
            counter.text = "बचा हुआ समय: $sec सेकंड\nइमरजेंसी: वॉल्यूम-डाउन 5 सेकंड दबाए रखो"
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        active = true
        goHome = intent.getBooleanExtra(EXTRA_GO_HOME, true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        counter = TextView(this)

        if (Prefs.hasVideo(this)) {
            val v = VideoView(this)
            video = v
            root.addView(
                v,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER
                )
            )
            v.setOnPreparedListener {
                v.start()
                handler.post(tick)
            }
            v.setOnCompletionListener { done(goHome) }
            v.setOnErrorListener { _, _, _ ->
                done(goHome)
                true
            }
            v.setVideoPath(Prefs.videoFile(this).absolutePath)
        } else {
            // वीडियो नहीं चुनी तो 15 सेकंड का टेक्स्ट
            endAt = SystemClock.uptimeMillis() + NO_VIDEO_MS
            handler.post(tick)
            handler.postDelayed({ done(goHome) }, NO_VIDEO_MS)
        }

        val title = TextView(this)
        title.text = "खुद को संभाल 💪"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setPadding(dp(16), dp(48), dp(16), dp(16))
        root.addView(
            title,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        counter.setTextColor(Color.parseColor("#CCCCCC"))
        counter.textSize = 14f
        counter.gravity = Gravity.CENTER
        counter.setPadding(dp(16), dp(16), dp(16), dp(48))
        root.addView(
            counter,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        setContentView(root)
        hideBars()

        // हर हाल में 5 मिनट बाद खुल जाएगा
        handler.postDelayed({ done(goHome) }, HARD_CAP_MS)
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    // टच बिल्कुल बंद
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean = true

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event != null) {
            if (event.repeatCount == 0) {
                volStart = SystemClock.uptimeMillis()
            } else if (SystemClock.uptimeMillis() - volStart >= ESCAPE_MS) {
                done(false)
                return true
            }
            return super.onKeyDown(keyCode, event)
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // बैक बंद
    }

    private fun done(home: Boolean) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        if (home) {
            val h = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(h)
        }
        finish()
    }

    override fun onStop() {
        super.onStop()
        // Home/Recents दबाया या स्क्रीन बंद हुई: अटका हुआ स्क्रीन न छोड़ें
        if (!finished) done(false)
    }

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
