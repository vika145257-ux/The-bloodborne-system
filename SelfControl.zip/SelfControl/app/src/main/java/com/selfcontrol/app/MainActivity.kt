package com.selfcontrol.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var grid: GridView
    private var apps: List<AppItem> = emptyList()
    private var blocked: Set<String> = emptySet()
    private var enabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101418"))
        root.setPadding(dp(16), dp(40), dp(16), dp(16))

        val title = TextView(this)
        title.text = "खुद को संभाल"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        status = TextView(this)
        status.textSize = 13f
        status.setPadding(0, dp(8), 0, dp(12))
        status.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(status)

        grid = GridView(this)
        grid.numColumns = 4
        grid.verticalSpacing = dp(8)
        grid.setOnItemClickListener { _, _, pos, _ -> onAppTap(apps[pos]) }
        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val settingsBtn = Button(this)
        settingsBtn.text = "⚙  सेटिंग"
        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        root.addView(settingsBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        apps = Apps.launchable(this)
        blocked = Prefs.blocked(this)
        enabled = Prefs.isEnabled(this)
        grid.adapter = AppAdapter()

        if (a11yOn()) {
            status.text = "✅ असली ऐप (Instagram, Chrome...) भी रुकेंगे"
            status.setTextColor(Color.parseColor("#7CE38B"))
        } else {
            status.text = "⚠ असली ऐप रोकने के लिए यहाँ दबाओ और \"खुद को संभाल\" को Accessibility में चालू करो"
            status.setTextColor(Color.parseColor("#FFB74D"))
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun onAppTap(app: AppItem) {
        if (enabled && app.pkg in blocked) {
            startActivity(
                Intent(this, LockVideoActivity::class.java)
                    .putExtra(LockVideoActivity.EXTRA_GO_HOME, false)
            )
        } else {
            packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
        }
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = apps[position]
            val ctx = this@MainActivity

            val cell = LinearLayout(ctx)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(ctx.dp(4), ctx.dp(8), ctx.dp(4), ctx.dp(8))

            val icon = ImageView(ctx)
            icon.setImageDrawable(app.icon)
            cell.addView(icon, LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))

            val label = TextView(ctx)
            val lock = enabled && app.pkg in blocked
            label.text = if (lock) "🔒 ${app.label}" else app.label
            label.setTextColor(Color.WHITE)
            label.textSize = 11f
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.END
            label.gravity = Gravity.CENTER
            cell.addView(label)

            return cell
        }
    }
}
