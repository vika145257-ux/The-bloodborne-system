package com.selfcontrol.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView

/**
 * वीडियो चलती है, टच और बैक बंद। वीडियो ख़त्म होते ही अपने-आप नॉर्मल।
 *
 * "वीडियो न कटे" चालू हो तो Home/Recents दबाने पर भी BlockerService वीडियो वहीं से वापस ले आती है।
 * सुरक्षा के लिए फ़ोन फँसेगा नहीं:
 *  1) पूरे सेशन की हद 5 मिनट (Home दबा-दबाकर बढ़ाई नहीं जा सकती)
 *  2) कॉल आए/चल रही हो तो लॉक हट जाता है
 *  3) वीडियो में एरर आए तो तुरंत खुल जाता है
 *  4) वॉल्यूम-डाउन 5 सेकंड दबाए रखो तो इमरजेंसी एग्ज़िट (होम पर पहुँचाता है)
 *  5) पावर बटन से स्क्रीन बंद करने पर सेशन ख़त्म; खोलने पर चुना हुआ ऐप सामने हो तो वीडियो फिर शुरू से
 */
class LockVideoActivity : Activity() {

    companion object {
        const val EXTRA_GO_HOME = "go_home"
        const val HARD_CAP_MS = 5 * 60 * 1000L
        private const val NO_VIDEO_MS = 15_000L
        private const val ESCAPE_MS = 5_000L

        /** अभी स्क्रीन पर यही activity है */
        @Volatile
        var active = false

        /** वीडियो का सेशन शुरू हो चुका है और अभी पूरा नहीं हुआ */
        @Volatile
        var pending = false

        @Volatile
        var sessionStart = 0L

        @Volatile
        var resumePos = 0

        fun endSession() {
            pending = false
            resumePos = 0
        }

        fun inCall(c: Context): Boolean {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val m = am.mode
            return m == AudioManager.MODE_RINGTONE ||
                    m == AudioManager.MODE_IN_CALL ||
                    m == AudioManager.MODE_IN_COMMUNICATION
        }

        /** वीडियो बीच में छूटी है और अब भी वापस लानी है? */
        fun shouldResume(c: Context): Boolean {
            if (!pending || active) return false
            if (!Prefs.uncuttable(c)) {
                endSession()
                return false
            }
            if (SystemClock.uptimeMillis() - sessionStart >= HARD_CAP_MS) {
                endSession()
                return false
            }
            if (inCall(c)) {
                endSession()
                return false
            }
            return true
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var finished = false
    private var goHome = true
    private var volStart = 0L
    private var endAt = 0L
    private var video: VideoView? = null
    private lateinit var counter: TextView

    private val tick = object : Runnable {
        override fun run() {
            if (finished) return
            if (inCall(this@LockVideoActivity)) {
                done(false)
                return
            }
            val v = video
            val leftMs: Long = if (v != null) {
                val pos = v.currentPosition
                if (pos > 0) resumePos = pos
                (v.duration - pos).toLong()
            } else {
                endAt - SystemClock.uptimeMillis()
            }
            val sec = leftMs.coerceAtLeast(0L) / 1000 + 1
            counter.text = "बचा हुआ समय: $sec सेकंड\nइमरजेंसी: वॉल्यूम-डाउन 5 सेकंड दबाए रखो"
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        active = true
        val now = SystemClock.uptimeMillis()
        // नया सेशन, या पुराना सेशन जो 5 मिनट की हद पार कर चुका है
        if (!pending || now - sessionStart >= HARD_CAP_MS) {
            pending = true
            sessionStart = now
            resumePos = 0
        }
        goHome = intent.getBooleanExtra(EXTRA_GO_HOME, true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        counter = TextView(this)

        if (Prefs.hasVideo(this)) {
            val v = VideoView(this)
            video = v
            root.addView(
                v,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER
                )
            )
            v.setOnPreparedListener {
                if (resumePos > 0) v.seekTo(resumePos)
                v.start()
                handler.post(tick)
            }
            v.setOnCompletionListener { done(goHome) }
            v.setOnErrorListener { _, _, _ ->
                done(goHome)
                true
            }
            v.setVideoPath(Prefs.videoFile(this).absolutePath)
        } else {
            // वीडियो नहीं चुनी तो 15 सेकंड का टेक्स्ट
            endAt = sessionStart + NO_VIDEO_MS
            handler.post(tick)
            handler.postDelayed({ done(goHome) }, (endAt - now).coerceAtLeast(0L))
        }

        val title = TextView(this)
        title.text = "खुद को संभाल 💪"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setPadding(dp(16), dp(48), dp(16), dp(16))
        root.addView(
            title,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        counter.setTextColor(Color.parseColor("#CCCCCC"))
        counter.textSize = 14f
        counter.gravity = Gravity.CENTER
        counter.setPadding(dp(16), dp(16), dp(16), dp(48))
        root.addView(
            counter,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        setContentView(root)
        hideBars()

        // पूरे सेशन की हद: कितनी भी बार Home दबाओ, 5 मिनट से ज़्यादा नहीं
        handler.postDelayed({ done(goHome) }, (sessionStart + HARD_CAP_MS - now).coerceAtLeast(0L))
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    // टच बिल्कुल बंद
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean = true

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event != null) {
            if (event.repeatCount == 0) {
                volStart = SystemClock.uptimeMillis()
            } else if (SystemClock.uptimeMillis() - volStart >= ESCAPE_MS) {
                done(true)
                return true
            }
            return super.onKeyDown(keyCode, event)
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // बैक बंद
    }

    override fun onPause() {
        // स्क्रीन से हटने से पहले वीडियो की जगह याद रखो
        video?.let {
            val pos = it.currentPosition
            if (pos > 0) resumePos = pos
        }
        super.onPause()
    }

    /** वीडियो पूरी/ख़त्म: सेशन बंद */
    private fun done(home: Boolean) {
        if (finished) return
        finished = true
        endSession()
        active = false
        handler.removeCallbacksAndMessages(null)
        if (home) {
            val h = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(h)
        }
        finish()
    }

    /** Home/Recents दबा: सेशन चालू रखो, BlockerService अगले event पर वीडियो वहीं से वापस लाएगी */
    private fun suspendForHome() {
        if (finished) return
        finished = true
        active = false
        handler.removeCallbacksAndMessages(null)
        finish()
        BlockerService.instance?.resumeSoon()
    }

    override fun onStop() {
        super.onStop()
        if (finished) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        when {
            // स्क्रीन बंद हुई: सेशन ख़त्म
            !pm.isInteractive -> done(false)
            // कॉल आई: लॉक हटाओ
            inCall(this) -> done(false)
            // वीडियो न कटे चालू: बाद में वापस आएगी
            Prefs.uncuttable(this) -> suspendForHome()
            else -> done(false)
        }
    }

    override fun onDestroy() {
        if (!finished) active = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
