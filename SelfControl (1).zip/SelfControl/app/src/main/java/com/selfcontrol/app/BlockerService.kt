package com.selfcontrol.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * सिर्फ़ यह देखता है कि किस ऐप की window सामने है (package name).
 * स्क्रीन का टेक्स्ट/डेटा न पढ़ता है, न सेव करता है, और ऐप में INTERNET permission भी नहीं है।
 *
 * 1) चुने हुए ऐप का event आए तो थोड़ी देर रुककर जाँचता है कि सच में वही ऐप सामने है।
 *    होम स्क्रीन / लॉक स्क्रीन / कोई और ऐप सामने हो तो वीडियो नहीं चलती।
 * 2) "वीडियो न कटे" चालू हो और वीडियो बीच में छूट गई हो (Home/Recents दबाया),
 *    तो अगले event पर वीडियो वहीं से वापस ले आता है।
 */
class BlockerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BlockerService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastLaunch = 0L
    private var pendingPkg: String? = null
    private var tries = 0

    private val verify = Runnable {
        val pkg = pendingPkg ?: return@Runnable
        val root = rootInActiveWindow
        val front = root?.packageName?.toString()
        root?.recycle()
        when {
            front == pkg -> launchLock()
            // सामने वाली window पढ़ी नहीं जा सकी: दो बार दोबारा देखो, फिर भी न मिले तो ब्लॉक कर दो
            front == null && tries >= 2 -> launchLock()
            // अभी कोई और ऐप / होम / लॉक स्क्रीन सामने है: करीब 2 सेकंड तक इंतज़ार, फिर छोड़ दो
            tries < 6 -> {
                tries++
                schedule(pkg, 350)
            }
        }
    }

    private fun schedule(pkg: String, delayMs: Long) {
        pendingPkg = pkg
        handler.removeCallbacks(verify)
        handler.postDelayed(verify, delayMs)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (!Prefs.isEnabled(this)) {
            LockVideoActivity.endSession()
            return
        }

        // वीडियो बीच में छूटी है (Home/Recents दबाया): वहीं से वापस ले आओ
        if (LockVideoActivity.shouldResume(this)) {
            launchLock(500L)
            return
        }

        if (LockVideoActivity.active) return
        if (pkg !in Prefs.blocked(this)) return

        if (Prefs.noHomeLaunch(this)) {
            tries = 0
            schedule(pkg, 400)
        } else {
            launchLock()
        }
    }

    private fun launchLock(minGapMs: Long = 1500L) {
        if (LockVideoActivity.active) return
        val now = SystemClock.uptimeMillis()
        if (now - lastLaunch < minGapMs) return
        lastLaunch = now

        val i = Intent(this, LockVideoActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(i)
    }

    /** LockVideoActivity बीच में हटी (Home/Recents): थोड़ी देर बाद वीडियो वापस लाओ */
    fun resumeSoon() {
        handler.postDelayed({
            if (Prefs.isEnabled(this) && LockVideoActivity.shouldResume(this)) {
                launchLock(300L)
            }
        }, 300)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onInterrupt() {
        handler.removeCallbacks(verify)
    }

    override fun onDestroy() {
        handler.removeCallbacks(verify)
        if (instance === this) instance = null
        super.onDestroy()
    }
}
