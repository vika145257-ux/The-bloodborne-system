package com.selfcontrol.app

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import java.io.File

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Prefs {
    private val DEFAULT_BLOCKED = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.android.chrome"
    )

    private fun sp(c: Context) = c.getSharedPreferences("selfcontrol", Context.MODE_PRIVATE)

    fun isEnabled(c: Context): Boolean = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** true = वीडियो सिर्फ़ तब चले जब चुना हुआ ऐप सच में सामने खुला हो (होम/लॉक स्क्रीन पर नहीं) */
    fun noHomeLaunch(c: Context): Boolean = sp(c).getBoolean("no_home", true)
    fun setNoHomeLaunch(c: Context, v: Boolean) = sp(c).edit().putBoolean("no_home", v).apply()

    /** true = वीडियो के दौरान Home/Recents दबाने पर भी वीडियो वापस आ जाए */
    fun uncuttable(c: Context): Boolean = sp(c).getBoolean("uncuttable", true)
    fun setUncuttable(c: Context, v: Boolean) = sp(c).edit().putBoolean("uncuttable", v).apply()

    fun blocked(c: Context): Set<String> =
        sp(c).getStringSet("blocked", null)?.toSet() ?: DEFAULT_BLOCKED

    fun setBlocked(c: Context, s: Set<String>) =
        sp(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun pin(c: Context): String = sp(c).getString("pin", "") ?: ""
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", p).apply()

    fun videoFile(c: Context): File = File(c.filesDir, "lock_video.mp4")
    fun hasVideo(c: Context): Boolean = videoFile(c).let { it.exists() && it.length() > 0 }
}

object Apps {
    /** फ़ोन के सभी launcher ऐप (अपने को छोड़कर), नाम से sorted */
    fun launchable(c: Context): List<AppItem> {
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }
}
