package com.selfcontrol.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101418"))
        root.setPadding(dp(20), dp(56), dp(20), dp(20))

        val title = TextView(this)
        title.text = "खुद को संभाल"
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        status = TextView(this)
        status.textSize = 14f
        status.setPadding(0, dp(16), 0, dp(8))
        status.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(status)

        info = TextView(this)
        info.textSize = 14f
        info.setTextColor(Color.parseColor("#CCCCCC"))
        info.setPadding(0, dp(8), 0, dp(16))
        root.addView(info)

        addButton(root, "⚙  सेटिंग") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        addButton(root, "▶  वीडियो टेस्ट करो") {
            startActivity(
                Intent(this, LockVideoActivity::class.java)
                    .putExtra(LockVideoActivity.EXTRA_GO_HOME, false)
            )
        }

        setContentView(root)
    }

    private fun addButton(root: LinearLayout, text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        root.addView(b, lp)
    }

    override fun onResume() {
        super.onResume()

        if (a11yOn()) {
            status.text = "✅ चालू है: चुने हुए ऐप (Chrome, Instagram...) सीधे खोलने पर भी वीडियो चलेगी"
            status.setTextColor(Color.parseColor("#7CE38B"))
        } else {
            status.text = "⚠ अभी असली ऐप नहीं रुकेंगे। यहाँ दबाओ और \"खुद को संभाल\" को Accessibility में चालू करो"
            status.setTextColor(Color.parseColor("#FFB74D"))
        }

        val blocked = Prefs.blocked(this)
        val names = Apps.launchable(this).filter { it.pkg in blocked }.map { it.label }
        val on = Prefs.isEnabled(this)
        info.text = "ब्लॉकिंग: " + (if (on) "चालू" else "बंद") +
                "\nरोके हुए ऐप: " + (if (names.isEmpty()) "कोई नहीं चुना" else names.joinToString(", ")) +
                "\nवीडियो: " + (if (Prefs.hasVideo(this)) "चुनी हुई है" else "नहीं चुनी")
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }
}
